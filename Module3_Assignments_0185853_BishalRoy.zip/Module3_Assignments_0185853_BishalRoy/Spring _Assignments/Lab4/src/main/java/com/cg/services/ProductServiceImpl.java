package com.cg.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ProductDAO;

import com.cg.entities.Product;
import com.cg.exceptions.ApplicationException;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

    @Autowired private ProductDAO dao;
    
    @Transactional(readOnly=true)
    public Product find(int productId) {
       Product p1= dao.findById(productId);
         if(p1 == null) {
            throw new ApplicationException("Product does not Exists!");
        }
        return p1;
    }

    @Transactional(readOnly=true)
    public List<Product> getAll() {
    	
    	 List<Product> prods = dao.findAll();
         if(prods == null || prods.isEmpty()) {
             throw new ApplicationException("Product List is Empty");
         }
         return prods;
    	
       
    }

    @Transactional(propagation=Propagation.REQUIRED)
    public void create(Product p1) {
       
        Product temp1 = dao.findById(p.getProductId());
        if(temp1==null)
        {
            dao.save(p1);
        }else
            throw new ApplicationException("Product Already Exists!");
    }

}