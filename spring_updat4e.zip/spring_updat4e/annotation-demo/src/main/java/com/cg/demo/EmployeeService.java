package com.cg.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


@Service
//@Component
public class EmployeeService {
	@Autowired
	private EmployeeDao dao;

	public EmployeeDao getDao() {
		return dao;
	}
	

	public void setDao(EmployeeDao dao) {
		System.out.println("Preparing Setter injection");
		this.dao = dao;
	}
	
	

}
