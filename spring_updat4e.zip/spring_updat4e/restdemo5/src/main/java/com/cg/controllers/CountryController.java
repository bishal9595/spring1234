package com.cg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Country;
import com.cg.service.CountryService;

@RestController
@RequestMapping("/countries")

public class CountryController {

    @Autowired CountryService service;
    
    @GetMapping(value="/code/{code}")	
    public Country findbycode(@PathVariable String code) {
        return service.find(code);
    }
    
    @GetMapping(value="/get")
    public List<Country> getall(){
        return service.getAll();
    }
    
    @PostMapping(value="/new",consumes= {"application/json"})
    public String save(@RequestBody Country country) {
        service.create(country);
        return "country added!";
    }
    
    @PostMapping(value="/update",consumes= {"application/json"})
    public String update(@RequestBody Country country) {
        service.update(country);
        return "country updated";
    }    
    @PutMapping(value="/delete",consumes= {"application/json"})
    public String del(@RequestBody Country country) {
        service.deletes(country);
        return "country deleted";
    }  
}