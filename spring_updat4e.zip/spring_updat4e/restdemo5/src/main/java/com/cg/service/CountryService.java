package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.daos.CountryDAO;
import com.cg.entities.Country;

import com.cg.exceptions.ApplicationException;


public interface CountryService {

	Country find(String code);
    List<Country> getAll();
    void create(Country p);
    public void update(Country p);
    
    public void deletes(Country p);
}