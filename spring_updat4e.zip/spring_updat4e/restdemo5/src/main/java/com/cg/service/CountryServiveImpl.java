package com.cg.service;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.daos.CountryDAO;
import com.cg.entities.Country;


@Service
@Transactional
public class CountryServiveImpl implements CountryService{

	 @Autowired 
	    private CountryDAO dao;
	 @PostConstruct
	    public void populateSample() {
	        dao.save(new Country("IN", "India", "Asia", "New Delhi"));
	        dao.save(new Country("SK","Sri Lanka","Asia","Colambo"));
	        dao.save(new Country("USA","United States of America","North America","Washington DC"));
	    }
	    
	    
	    @Transactional(readOnly=true)
	    public Country find(String code) {
	        Optional<Country> c = dao.findById(code);
	        if(c.isPresent()) {
	            return c.get();
	        }
	        else
	            throw new RuntimeException("Country not found!");
	    }

	    @Transactional(readOnly=true)
	public List<Country> getAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	 @Transactional(propagation=Propagation.REQUIRED)
	    public void create(Country p) {
	        if(dao.existsById(p.getCode())) {
	            throw new RuntimeException("Country Already exists!!");
	        }
	        dao.save(p);
	    }

	 @Transactional(propagation=Propagation.REQUIRED)
		public
	    void update(Country p)
	    {   if(dao.existsById(p.getCode())) {
	    	 dao.save(p);
	    }}

	
	 @Transactional(propagation=Propagation.REQUIRED)
	public void deletes(Country p) 
		{   if(dao.existsById(p.getCode())) {
	    	 dao.delete(p);
	    }
		else
			throw new RuntimeException("error");
		}
}
