package com.cg.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.daos.ProductDAO;
import com.cg.entities.Product;


@Service
@Transactional
public class ProductServiceImpl implements ProductService {

    @Autowired 
    private ProductDAO dao;
    
    @Transactional(readOnly=true)
    public Product find(int productId) {
        Optional<Product> product = dao.findById(productId);
        if(product.isPresent()) {
            return product.get();
        }
        else
            throw new RuntimeException("Product not found!");
    }

    @Transactional(readOnly=true)
    public List<Product> getAll() {
        return dao.findAll();
    }

    @Transactional(propagation=Propagation.REQUIRED)
    public void create(Product p) {
        if(dao.existsById(p.getProductId())) {
            throw new RuntimeException("Product Already exists!!");
        }
        dao.save(p);
    }
    @Transactional(propagation=Propagation.REQUIRED)
	public
    void update(Product p)
    {   if(dao.existsById(p.getProductId())) {
    	 dao.save(p);
    }
    	
    }
    @Transactional(readOnly=true)
	public long count() {
		// TODO Auto-generated method stub
		return dao.count();
	}
    @Transactional(propagation=Propagation.REQUIRED)
	public void deletes(Product p) {
		// TODO Auto-generated method stub
		if(dao.existsById(p.getProductId())) {
			dao.delete(p);
		}
		
	}
}