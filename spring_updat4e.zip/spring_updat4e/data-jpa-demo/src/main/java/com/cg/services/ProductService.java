package com.cg.services;

import java.util.List;

import com.cg.entities.Product;

public interface ProductService {
    Product find(int productId);
    List<Product> getAll();
    void create(Product p);
    public void update(Product p);
    public long count();
    public void deletes(Product p);
}