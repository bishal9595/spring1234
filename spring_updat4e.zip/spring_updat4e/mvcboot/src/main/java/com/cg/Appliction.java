package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Appliction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* THIS SINGLE LINE DOES THE FOLLOWING
		 * Create AnnotationConfigApplicationContext
		 * It uses @ComponentScan for all child packages
		 *     It picks up HelloController class
		 *     does RequstMapping("/")
		 *     Reads application.properties and reads the property server.port=3000 in it
		 *     launches embedded Tomcat server and deploy HelloController 
		 *     Wait for you to terminate the process
		 */
		SpringApplication.run(Appliction.class,args);

	}

}
