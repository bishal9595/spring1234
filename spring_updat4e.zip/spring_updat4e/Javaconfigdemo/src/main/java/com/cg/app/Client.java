package com.cg.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.cg.EmployeeDao;
import com.cg.EmployeeService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new AnnotationConfigApplicationContext(Appconfig.class);
		EmployeeDao dao=context.getBean("dao",EmployeeDao.class);
		EmployeeService service=context.getBean(EmployeeService.class);
		System.out.println("Dao"+dao);
		System.out.println("service"+service);

	}

}
