package com.cg.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.EmployeeDao;
import com.cg.EmployeeService;
/*
@Configuration
public class Appconfig {
	
	@Bean
	public EmployeeDao dao()
	{
		return new EmployeeDao();
	}
	@Bean
	public EmployeeService service()
	{
		EmployeeService service=new EmployeeService();
		service.setDao(dao());
		return service;
	}
*/
@Configuration
@ComponentScan("com.cg")
public class Appconfig {
}
	

