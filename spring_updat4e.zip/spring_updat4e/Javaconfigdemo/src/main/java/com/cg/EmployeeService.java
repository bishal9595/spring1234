package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	
	private EmployeeDao dao;

	public EmployeeDao getDao() {
		return dao;
	}
	
	@Autowired
	public void setDao(EmployeeDao dao) {
		
		this.dao = dao;
	}
	
	

}
