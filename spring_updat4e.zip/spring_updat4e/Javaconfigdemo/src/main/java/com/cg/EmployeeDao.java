package com.cg;

import org.springframework.stereotype.Repository;
@Repository("dao")
public class EmployeeDao {
	
	

}
