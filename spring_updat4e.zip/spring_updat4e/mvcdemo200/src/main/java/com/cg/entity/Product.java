package com.cg.entity;
import java.util.List;

import javax.validation.constraints.*;


public class Product {
@NotNull
@Max(value=10000,message="id cannot be greater than 10000")
private	Integer productId;
@NotEmpty(message="Name cannot be empty")
private String name;
@Size(min=1,max=3,message="must have atleast 3 characters")
private String description;
@NotNull
private Double price;
List<Product> prod;
public List<Product> getProd() {
	return prod;
}

public void setProd(List<Product> prod) {
	this.prod = prod;
}

public Product()
{
	
}

public Product(Integer productId, String name, String description, Double price) {
	super();
	this.productId = productId;
	this.name = name;
	this.description = description;
	this.price = price;
}


public Integer getProductId() {
	return productId;
}
public void setProductId(Integer productId) {
	this.productId = productId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public Double getPrice() {
	return price;
}
public void setPrice(Double price) {
	this.price = price;
}




}
