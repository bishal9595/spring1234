package com.cg.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class Searchcontroller {
	
	
	
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public String search(Model model,@RequestParam("q") String query){
		System.out.println("Searching:"+query);
		model.addAttribute("msg","Welcome to spring"+query+"is cureently unavailable");
		return "home";
	}
	@RequestMapping(value="/interest",method=RequestMethod.GET)
	public String in(Model model,@RequestParam("p") double x,@RequestParam("r") double y,@RequestParam("t") int z){
		double result=(x*y*z)/100;
		model.addAttribute("msg",result);
		return "home";
	}

}
