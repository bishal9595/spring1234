package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();                //adding
		Author auth = new Author();
		auth.setFirstName("Ariz");
		auth.setMiddleName("Ahmad");
		auth.setLastName("Usmani");
		auth.setPhoneNo(9873921429L);
		em.persist(auth);
		em.flush();
		em.getTransaction().commit();
		
		Author auth2=new Author();			        //updating
		auth2.setAuthorId(43);
		auth2.setFirstName("Vinay");
		auth2.setMiddleName("Pratap");
		auth2.setLastName("Singh");
		auth2.setPhoneNo(999999999L);
		em.getTransaction().begin();
		em.merge(auth2);
		em.getTransaction().commit();
		
		/*
		Author auth3=em.find(Author.class,44);		//deleting
		em.getTransaction().begin();
		em.remove(auth3);
		em.getTransaction().commit();
		*/
		
		Author auth4=em.find(Author.class,42);      //searching
		System.out.println(auth4.getAuthorId());
		System.out.println(auth4.getFirstName());
		System.out.println(auth4.getMiddleName());
		System.out.println(auth4.getLastName());
		System.out.println(auth4.getPhoneNo());
	}
}